import React from 'react';
import { ArrowRight, Sparkles, Cpu, Globe, Zap } from 'lucide-react';

const Hero: React.FC = () => {
  const handleGetStartedClick = () => {
    window.open('https://wa.me/212665848588', '_blank');
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Enhanced Animated Background Elements */}
      <div className="absolute inset-0">
        {/* Enhanced Floating Geometric Shapes */}
        <div className="absolute top-20 left-20 w-24 h-24 bg-gradient-to-r from-cyan-400/30 to-blue-500/30 rounded-full blur-xl animate-float-3d transform-gpu"></div>
        <div className="absolute top-60 right-32 w-40 h-40 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-lg blur-xl animate-float-3d-delayed transform rotate-45 transform-gpu"></div>
        <div className="absolute bottom-40 left-40 w-20 h-20 bg-gradient-to-r from-green-400/30 to-cyan-400/30 rounded-full blur-xl animate-float-3d-slow transform-gpu"></div>
        <div className="absolute top-1/3 left-1/2 w-32 h-32 bg-gradient-to-r from-orange-400/20 to-red-500/20 rounded-full blur-2xl animate-float-3d transform-gpu"></div>
        
        {/* Enhanced Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_0%,#000_70%,transparent_110%)]"></div>
        
        {/* Additional Floating Elements */}
        <div className="absolute top-1/4 right-1/3 w-16 h-16 bg-gradient-to-r from-pink-400/25 to-purple-500/25 rounded-lg blur-lg animate-float-3d transform rotate-12 transform-gpu"></div>
        <div className="absolute bottom-1/4 right-1/4 w-28 h-28 bg-gradient-to-r from-blue-400/20 to-cyan-500/20 rounded-full blur-xl animate-float-3d-delayed transform-gpu"></div>
      </div>

      {/* Enhanced 3D Floating Icons */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 animate-float-3d perspective-1000">
          <div className="relative group transform-gpu">
            <Cpu className="w-16 h-16 text-cyan-400/70 transform perspective-1000 rotateX-12 rotateY-12 group-hover:rotateX-24 group-hover:rotateY-24 transition-transform duration-500" />
            <div className="absolute inset-0 bg-cyan-400/30 rounded-full blur-2xl scale-150 animate-pulse-glow"></div>
          </div>
        </div>
        <div className="absolute top-1/3 right-1/4 animate-float-3d-delayed perspective-1000">
          <div className="relative group transform-gpu">
            <Globe className="w-20 h-20 text-purple-400/70 transform perspective-1000 rotateX-24 rotateY-24 group-hover:rotateX-45 group-hover:rotateY-45 transition-transform duration-500" />
            <div className="absolute inset-0 bg-purple-400/30 rounded-full blur-2xl scale-150 animate-pulse-glow"></div>
          </div>
        </div>
        <div className="absolute bottom-1/3 left-1/3 animate-float-3d-slow perspective-1000">
          <div className="relative group transform-gpu">
            <Sparkles className="w-12 h-12 text-pink-400/70 transform perspective-1000 rotateX-6 rotateY-6 group-hover:rotateX-12 group-hover:rotateY-12 transition-transform duration-500" />
            <div className="absolute inset-0 bg-pink-400/30 rounded-full blur-2xl scale-150 animate-pulse-glow"></div>
          </div>
        </div>
        <div className="absolute top-1/2 right-1/3 animate-float-3d perspective-1000">
          <div className="relative group transform-gpu">
            <Zap className="w-14 h-14 text-green-400/70 transform perspective-1000 rotateX-18 rotateY-18 group-hover:rotateX-36 group-hover:rotateY-36 transition-transform duration-500" />
            <div className="absolute inset-0 bg-green-400/30 rounded-full blur-2xl scale-150 animate-pulse-glow"></div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 animate-fade-in-up">
          {/* Enhanced Badge */}
          <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-6 py-3 text-sm text-gray-300 transform hover:scale-105 transition-all duration-300 perspective-1000 hover:rotateX-6">
            <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            <span>Next-Generation Technology Solutions from Morocco</span>
          </div>

          {/* Enhanced Main Headline */}
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold text-white leading-tight perspective-1000">
            <span className="block transform hover:rotateX-6 transition-transform duration-500">Transform Your</span>
            <span className="block bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent animate-gradient-x transform hover:rotateX-6 transition-transform duration-500">
              Digital Future
            </span>
          </h1>

          {/* Enhanced Subtitle */}
          <p className="text-xl md:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed transform hover:scale-105 transition-transform duration-300">
            Unlock unprecedented growth with our cutting-edge AI-powered solutions. 
            We craft premium digital experiences that drive results and exceed expectations.
          </p>

          {/* Enhanced CTA Button - Single Button */}
          <div className="flex justify-center items-center mt-12">
            <button 
              onClick={handleGetStartedClick}
              className="group relative overflow-hidden bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-12 py-6 rounded-full font-semibold text-xl transition-all duration-300 transform hover:scale-110 hover:shadow-2xl hover:shadow-cyan-500/25 perspective-1000 hover:rotateX-6"
            >
              <span className="relative z-10 flex items-center space-x-3">
                <span>Start Your Journey</span>
                <ArrowRight className="w-6 h-6 group-hover:translate-x-2 group-hover:rotate-12 transition-transform duration-300" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="absolute inset-0 bg-white/20 rounded-full blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-300"></div>
            </button>
          </div>

          {/* Enhanced Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20 pt-16 border-t border-white/10">
            <div className="text-center group perspective-1000">
              <div className="text-5xl md:text-6xl font-bold text-white mb-3 group-hover:text-cyan-400 transition-all duration-300 transform group-hover:scale-110 group-hover:rotateX-6">
                500+
              </div>
              <div className="text-gray-400 text-lg">Projects Delivered</div>
            </div>
            <div className="text-center group perspective-1000">
              <div className="text-5xl md:text-6xl font-bold text-white mb-3 group-hover:text-purple-400 transition-all duration-300 transform group-hover:scale-110 group-hover:rotateX-6">
                98%
              </div>
              <div className="text-gray-400 text-lg">Client Satisfaction</div>
            </div>
            <div className="text-center group perspective-1000">
              <div className="text-5xl md:text-6xl font-bold text-white mb-3 group-hover:text-pink-400 transition-all duration-300 transform group-hover:scale-110 group-hover:rotateX-6">
                24/7
              </div>
              <div className="text-gray-400 text-lg">Premium Support</div>
            </div>
          </div>
        </div>
      </div>

      {/* Enhanced Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce perspective-1000">
        <div className="w-8 h-12 border-2 border-white/30 rounded-full flex justify-center transform hover:rotateX-12 transition-transform duration-300">
          <div className="w-2 h-4 bg-white/60 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;