import React from 'react';
import { Zap, Mail, Phone, MapPin, Twitter, Linkedin, Github, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  const socialLinks = [
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Github, href: "#", label: "GitHub" },
    { icon: Instagram, href: "#", label: "Instagram" }
  ];

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/212665848588', '_blank');
  };

  return (
    <footer className="bg-gradient-to-b from-gray-900 via-black to-gray-900 relative overflow-hidden">
      {/* Enhanced Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-full blur-3xl animate-float-3d"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-3xl animate-float-3d-delayed"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-green-400/5 to-cyan-400/5 rounded-full blur-3xl animate-float-3d-slow"></div>
      </div>

      <div className="relative z-10">
        {/* Main Footer Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Brand Section */}
            <div className="lg:col-span-1">
              <div className="flex items-center space-x-3 mb-6 group">
                <div className="relative perspective-1000">
                  <Zap className="h-12 w-12 text-cyan-400 group-hover:text-purple-400 transition-all duration-500 transform group-hover:rotateY-180 group-hover:rotateX-12 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-cyan-400/30 rounded-full blur-xl group-hover:bg-purple-400/30 transition-all duration-500 animate-pulse-glow"></div>
                </div>
                <span className="text-3xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300 transform group-hover:scale-105">
                  NEXUS
                </span>
              </div>
              
              <p className="text-gray-400 mb-8 leading-relaxed max-w-md text-lg">
                Transforming businesses through cutting-edge technology solutions. 
                We craft premium digital experiences that drive growth and exceed expectations.
              </p>

              {/* Enhanced Contact Info */}
              <div className="space-y-6">
                <div 
                  className="flex items-center space-x-4 text-gray-400 hover:text-cyan-400 transition-all duration-300 cursor-pointer group transform hover:scale-105 hover:translate-x-2"
                  onClick={handleWhatsAppClick}
                >
                  <div className="relative">
                    <Mail className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  <span className="text-lg">bakugoisokay@gmail.com</span>
                </div>
                <div 
                  className="flex items-center space-x-4 text-gray-400 hover:text-cyan-400 transition-all duration-300 cursor-pointer group transform hover:scale-105 hover:translate-x-2"
                  onClick={handleWhatsAppClick}
                >
                  <div className="relative">
                    <Phone className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  <span className="text-lg">+212 665 848 588</span>
                </div>
                <div className="flex items-center space-x-4 text-gray-400 hover:text-cyan-400 transition-all duration-300 group transform hover:scale-105 hover:translate-x-2">
                  <div className="relative">
                    <MapPin className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
                    <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  <span className="text-lg">Fes, Morocco</span>
                </div>
              </div>
            </div>

            {/* Enhanced CTA Section */}
            <div className="lg:col-span-1 flex items-center justify-center">
              <div className="bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8 relative overflow-hidden transform hover:scale-105 transition-all duration-500 group perspective-1000">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative z-10 text-center">
                  <h3 className="text-2xl md:text-3xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors duration-300">
                    Ready to Start?
                  </h3>
                  <p className="text-gray-300 mb-6">
                    Let's discuss your project and bring your vision to life.
                  </p>
                  <button 
                    onClick={handleWhatsAppClick}
                    className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all duration-300 transform hover:scale-110 hover:shadow-2xl hover:shadow-purple-500/25 group-hover:rotateX-6"
                  >
                    Contact on WhatsApp
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Newsletter Section */}
          <div className="mt-16 pt-12 border-t border-white/10">
            <div className="bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm border border-white/10 rounded-3xl p-8 relative overflow-hidden transform hover:scale-[1.02] transition-all duration-500 group perspective-1000">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-transparent to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="relative z-10 text-center">
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors duration-300">
                  Stay Ahead of the Curve
                </h3>
                <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                  Get exclusive insights, industry trends, and early access to our latest innovations. 
                  Join thousands of forward-thinking professionals.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-lg mx-auto">
                  <input 
                    type="email" 
                    placeholder="Enter your email address"
                    className="flex-1 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-6 py-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:border-transparent transition-all duration-300 transform focus:scale-105"
                  />
                  <button className="bg-gradient-to-r from-cyan-500 to-purple-600 text-white px-8 py-3 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-purple-500/25 hover:rotateX-6">
                    Subscribe
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Bottom Bar */}
        <div className="border-t border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              {/* Copyright */}
              <div className="text-gray-400 text-sm mb-4 md:mb-0">
                © 2025 Nexus. All rights reserved. Crafted with precision and passion in Morocco.
              </div>

              {/* Enhanced Social Links */}
              <div className="flex items-center space-x-6">
                {socialLinks.map((social, index) => {
                  const IconComponent = social.icon;
                  return (
                    <a
                      key={index}
                      href={social.href}
                      aria-label={social.label}
                      className="w-12 h-12 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full flex items-center justify-center text-gray-400 hover:text-white hover:bg-cyan-500/20 hover:border-cyan-400/50 transition-all duration-300 transform hover:scale-110 hover:rotateY-12 perspective-1000 group"
                    >
                      <IconComponent className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
                      <div className="absolute inset-0 bg-cyan-400/20 rounded-full blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-300"></div>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;