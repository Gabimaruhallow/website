import React from 'react';
import { Rocket, Lock, Zap, Users, Globe, Award } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: Rocket,
      title: "Rapid Deployment",
      description: "Go from concept to production in record time with our streamlined development process.",
      metric: "75% Faster",
      color: "from-blue-500 to-cyan-400"
    },
    {
      icon: Lock,
      title: "Fort Knox Security",
      description: "Military-grade encryption and security protocols protect your most valuable data.",
      metric: "Zero Breaches",
      color: "from-red-500 to-orange-400"
    },
    {
      icon: Zap,
      title: "Lightning Performance",
      description: "Optimized code and infrastructure deliver blazing-fast response times.",
      metric: "<100ms Response",
      color: "from-yellow-400 to-orange-500"
    },
    {
      icon: Users,
      title: "Scalable Architecture",
      description: "Handle millions of users with auto-scaling infrastructure that grows with you.",
      metric: "10M+ Users",
      color: "from-green-400 to-emerald-500"
    },
    {
      icon: Globe,
      title: "Global Reach",
      description: "CDN-powered delivery ensures optimal performance worldwide.",
      metric: "99.9% Uptime",
      color: "from-purple-500 to-violet-400"
    },
    {
      icon: Award,
      title: "Award Winning",
      description: "Industry-recognized excellence in design and development.",
      metric: "50+ Awards",
      color: "from-pink-500 to-rose-400"
    }
  ];

  return (
    <section id="features" className="py-24 bg-gradient-to-b from-black via-gray-900 to-black relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center space-x-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full px-4 py-2 text-sm text-gray-300 mb-6">
            <Rocket className="w-4 h-4 text-cyan-400" />
            <span>Why Choose Excellence</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
              Unmatched Performance
            </span>
            <br />Meets Innovation
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Experience the difference that premium engineering and thoughtful design make. 
            Our solutions don't just meet expectations—they redefine them.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div 
                key={index}
                className="group relative perspective-1000"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-3xl p-8 transition-all duration-700 transform-gpu group-hover:rotateY-6 group-hover:rotateX-6 group-hover:scale-105">
                  {/* Glow Effect */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${feature.color} opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500 transform group-hover:scale-110`}></div>
                  
                  {/* Metric Badge */}
                  <div className={`absolute -top-4 -right-4 bg-gradient-to-r ${feature.color} text-white text-xs font-bold px-3 py-2 rounded-full shadow-lg transform rotate-12 group-hover:rotate-0 transition-transform duration-300`}>
                    {feature.metric}
                  </div>

                  {/* Icon */}
                  <div className="relative mb-6">
                    <div className={`w-20 h-20 bg-gradient-to-r ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 shadow-lg`}>
                      <IconComponent className="w-10 h-10 text-white" />
                    </div>
                    {/* Icon Glow */}
                    <div className={`absolute top-0 left-0 w-20 h-20 bg-gradient-to-r ${feature.color} rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-500`}></div>
                  </div>

                  {/* Content */}
                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors duration-300">
                    {feature.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {feature.description}
                  </p>

                  {/* Animated Border */}
                  <div className="absolute inset-0 rounded-3xl">
                    <div className={`absolute inset-0 rounded-3xl border-2 border-transparent bg-gradient-to-r ${feature.color} opacity-0 group-hover:opacity-30 transition-opacity duration-500`} style={{ padding: '2px' }}>
                      <div className="h-full w-full rounded-3xl bg-transparent"></div>
                    </div>
                  </div>

                  {/* Corner Accents */}
                  <div className={`absolute top-0 left-0 w-8 h-8 bg-gradient-to-br ${feature.color} rounded-tl-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500`}></div>
                  <div className={`absolute bottom-0 right-0 w-8 h-8 bg-gradient-to-tl ${feature.color} rounded-br-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500`}></div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Performance Metrics */}
        <div className="bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm border border-white/10 rounded-3xl p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-purple-500/5 to-pink-500/5"></div>
          <div className="relative z-10">
            <div className="text-center mb-12">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Performance That Speaks Volumes
              </h3>
              <p className="text-gray-300 text-lg max-w-2xl mx-auto">
                Our solutions consistently deliver measurable results that drive business growth 
                and exceed performance benchmarks.
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">
                  400%
                </div>
                <div className="text-gray-400">Performance Boost</div>
              </div>
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">
                  &lt;50ms
                </div>
                <div className="text-gray-400">Load Time</div>
              </div>
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">
                  99.99%
                </div>
                <div className="text-gray-400">Reliability</div>
              </div>
              <div className="text-center group">
                <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">
                  24/7
                </div>
                <div className="text-gray-400">Monitoring</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;